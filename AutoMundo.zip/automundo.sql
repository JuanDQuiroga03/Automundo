-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-03-2025 a las 17:59:37
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `automundo`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autos`
--

CREATE TABLE `autos` (
  `id` int(11) NOT NULL,
  `marca` varchar(50) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `anio` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `motor` varchar(50) NOT NULL,
  `transmision` varchar(50) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `autos`
--

INSERT INTO `autos` (`id`, `marca`, `modelo`, `anio`, `precio`, `motor`, `transmision`, `imagen`) VALUES
(1, 'Toyota', 'Corolla', 2023, 25000.00, '1.8L', 'Automática', 'corolla.jpg'),
(2, 'Honda', 'Civic', 2022, 27000.00, '2.0L', 'Manual', 'civic.jpg'),
(3, 'Ford', 'Mustang', 2021, 55000.00, '5.0L V8', 'Automática', 'mustang.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `autos_clasicos`
--

CREATE TABLE `autos_clasicos` (
  `id` int(11) NOT NULL,
  `marca` varchar(50) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `anio` int(11) NOT NULL,
  `historia` text NOT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `autos_clasicos`
--

INSERT INTO `autos_clasicos` (`id`, `marca`, `modelo`, `anio`, `historia`, `imagen`) VALUES
(1, 'Chevrolet', 'Bel Air', 1957, 'Un ícono de los años 50 con su estilo y potencia.', 'belair.jpg'),
(2, 'Volkswagen', 'Beetle', 1965, 'El clásico escarabajo, símbolo de durabilidad.', 'beetle.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE `noticias` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `contenido` text NOT NULL,
  `fecha` date NOT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `noticias`
--

INSERT INTO `noticias` (`id`, `titulo`, `contenido`, `fecha`, `imagen`) VALUES
(1, 'Tesla lanza nuevo modelo eléctrico', 'Tesla ha presentado su nuevo auto con mayor autonomía.', '2025-03-10', 'tesla.jpg'),
(2, 'Ford anuncia regreso del Bronco', 'El nuevo Bronco combina tecnología moderna con diseño clásico.', '2025-02-28', 'bronco.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `simulador_costos`
--

CREATE TABLE `simulador_costos` (
  `id` int(11) NOT NULL,
  `auto_id` int(11) NOT NULL,
  `cambio_aceite` decimal(10,2) NOT NULL,
  `cambio_frenos` decimal(10,2) NOT NULL,
  `cambio_llantas` decimal(10,2) NOT NULL,
  `otros` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `simulador_costos`
--

INSERT INTO `simulador_costos` (`id`, `auto_id`, `cambio_aceite`, `cambio_frenos`, `cambio_llantas`, `otros`) VALUES
(1, 1, 50.00, 200.00, 500.00, 100.00),
(2, 2, 60.00, 250.00, 600.00, 120.00);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `autos`
--
ALTER TABLE `autos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `autos_clasicos`
--
ALTER TABLE `autos_clasicos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `simulador_costos`
--
ALTER TABLE `simulador_costos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `auto_id` (`auto_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `autos`
--
ALTER TABLE `autos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `autos_clasicos`
--
ALTER TABLE `autos_clasicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `noticias`
--
ALTER TABLE `noticias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `simulador_costos`
--
ALTER TABLE `simulador_costos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `simulador_costos`
--
ALTER TABLE `simulador_costos`
  ADD CONSTRAINT `simulador_costos_ibfk_1` FOREIGN KEY (`auto_id`) REFERENCES `autos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
